package com.mansoor.bookstoreapi.dto;

public @interface XmlRootElement {

}
